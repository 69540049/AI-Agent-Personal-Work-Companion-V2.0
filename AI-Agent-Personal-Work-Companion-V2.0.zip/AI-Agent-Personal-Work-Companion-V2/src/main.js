const {app,BrowserWindow,ipcMain,safeStorage}=require('electron');
const path=require('path'),fs=require('fs');
const dir=app.getPath('userData'),dbFile=path.join(dir,'workspace.json'),keyFile=path.join(dir,'api-key.bin');
const seed={tasks:[
{id:'t1',title:'ตรวจสอบและติดตามงาน HR / DIT',project:'DIT / HRD',priority:'High',due:'',status:'In Progress'},
{id:'t2',title:'อัปเดต DIT Smart Onboarding 2027',project:'DIT Smart Onboarding',priority:'High',due:'',status:'Todo'},
{id:'t3',title:'พัฒนา Factory Tour Tracker',project:'DIT Factory Tour Tracker',priority:'Medium',due:'',status:'Todo'},
{id:'t4',title:'จัดการงานเรียนและ Assignment',project:'BUU / Learning',priority:'Medium',due:'',status:'Todo'},
{id:'t5',title:'วางแผน Content PRING SN',project:'PRING SN',priority:'Low',due:'',status:'Todo'}],
projects:[
{id:'p1',name:'DIT Smart Onboarding 2027',category:'DIT / HRD',progress:85,status:'In Progress',nextStep:'ตรวจสอบตาราง onboarding'},
{id:'p2',name:'DIT Factory Tour Tracker',category:'DIT / HRD',progress:70,status:'In Progress',nextStep:'พัฒนา checkpoint tracking'},
{id:'p3',name:'BUU / Learning & Assignment',category:'BUU',progress:62,status:'In Progress',nextStep:'ติดตามงานและกำหนดส่ง'},
{id:'p4',name:'PCM / Training & Game',category:'DIT / HRD',progress:55,status:'In Progress',nextStep:'พัฒนา learning experience'},
{id:'p5',name:'PRING SN Content & Travel',category:'Personal',progress:40,status:'Planning',nextStep:'จัดทำ content calendar'}],
workLogs:[],notes:[],preferences:{displayName:'PRING SN',launchAtLogin:true}};
function read(){try{if(!fs.existsSync(dbFile))fs.writeFileSync(dbFile,JSON.stringify(seed,null,2));return JSON.parse(fs.readFileSync(dbFile))}catch{return structuredClone(seed)}}
function write(d){fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(dbFile,JSON.stringify(d,null,2));return d}
function windowCreate(){const w=new BrowserWindow({width:1440,height:940,minWidth:1080,minHeight:720,backgroundColor:'#061326',titleBarStyle:'hiddenInset',trafficLightPosition:{x:16,y:15},webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true}});w.loadFile(path.join(__dirname,'index.html'))}
app.whenReady().then(()=>{windowCreate();app.setLoginItemSettings({openAtLogin:read().preferences.launchAtLogin!==false})});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
ipcMain.handle('data:get',()=>read());ipcMain.handle('data:save',(_,d)=>write(d));
ipcMain.handle('settings:get',()=>({preferences:read().preferences,hasApiKey:fs.existsSync(keyFile)}));
ipcMain.handle('settings:save',(_,s)=>{let d=read();d.preferences={...d.preferences,...(s.preferences||{})};write(d);if(s.apiKey!==undefined){if(s.apiKey){if(!safeStorage.isEncryptionAvailable())throw Error('macOS secure storage unavailable');fs.writeFileSync(keyFile,safeStorage.encryptString(s.apiKey))}else if(fs.existsSync(keyFile))fs.unlinkSync(keyFile)}app.setLoginItemSettings({openAtLogin:d.preferences.launchAtLogin!==false});return {preferences:d.preferences,hasApiKey:fs.existsSync(keyFile)}});
ipcMain.handle('ai:chat',async(_,p)=>{
if(!fs.existsSync(keyFile))throw Error('กรุณาตั้งค่า API Key ใน Settings ก่อนใช้งาน AI');
const key=safeStorage.decryptString(fs.readFileSync(keyFile)),cfg=p.settings||{},base=(cfg.baseURL||'https://api.openai.com/v1').replace(/\/$/,'');
const model=cfg.model||'gpt-4.1-mini',d=read();
const toolSpecs = [
  {name:'create_task',description:'Create a task',properties:{title:{type:'string'},project:{type:'string'},priority:{type:'string',enum:['High','Medium','Low']},due:{type:'string'},notes:{type:'string'}},required:['title']},
  {name:'update_task',description:'Update task by matching title',properties:{title:{type:'string'},status:{type:'string',enum:['Todo','In Progress','Done']},priority:{type:'string'},due:{type:'string'},notes:{type:'string'}},required:['title']},
  {name:'create_project',description:'Create project',properties:{name:{type:'string'},category:{type:'string'},progress:{type:'number'},nextStep:{type:'string'}},required:['name']},
  {name:'update_project',description:'Update project by matching name',properties:{name:{type:'string'},progress:{type:'number'},status:{type:'string'},nextStep:{type:'string'}},required:['name']},
  {name:'log_work',description:'Save work achievement',properties:{title:{type:'string'},project:{type:'string'},details:{type:'string'},outcome:{type:'string'}},required:['title','details']},
  {name:'save_note',description:'Save knowledge note',properties:{title:{type:'string'},content:{type:'string'},tags:{type:'string'}},required:['title','content']}
];
const tools=toolSpecs.map(t=>({type:'function',function:{name:t.name,description:t.description,parameters:{type:'object',properties:t.properties,required:t.required}}}));
const system=`คุณคือ Personal Work Companion ของ ${d.preferences.displayName}. ตอบภาษาไทยเป็นหลัก ช่วยวิเคราะห์ จัดเรียง วางแผน และจดจำงานได้. ใช้ tools เพื่อเขียนข้อมูลเมื่อผู้ใช้สั่งชัดเจนเท่านั้น. ห้ามอ้างว่าบันทึกสำเร็จถ้า tool ไม่สำเร็จ. ข้อมูล Workspace ปัจจุบัน: ${JSON.stringify({tasks:d.tasks,projects:d.projects,workLogs:d.workLogs.slice(0,15),notes:d.notes.slice(0,15)})}`;
const messages=[{role:'system',content:system},...(p.history||[]).slice(-12),{role:'user',content:p.message}];let answer='';
for(let i=0;i<5;i++){
const res=await fetch(base+'/chat/completions',{method:'POST',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({model,messages,tools,tool_choice:'auto',temperature:.35})});
const body=await res.json();if(!res.ok)throw Error(body.error?.message||'AI API '+res.status);
const m=body.choices?.[0]?.message;if(!m)throw Error('AI response invalid');messages.push(m);
if(!m.tool_calls?.length){answer=m.content||'ดำเนินการแล้วครับ';break}
for(const c of m.tool_calls){let a={};try{a=JSON.parse(c.function.arguments||'{}')}catch{}let result={ok:false,message:'ไม่พบข้อมูล'};
const now=new Date().toISOString(),task=d.tasks.find(x=>x.title.toLowerCase().includes((a.title||'').toLowerCase())),project=d.projects.find(x=>x.name.toLowerCase().includes((a.name||'').toLowerCase()));
if(c.function.name==='create_task'){let x={id:crypto.randomUUID(),title:a.title,project:a.project||'',priority:a.priority||'Medium',due:a.due||'',status:'Todo',notes:a.notes||''};d.tasks.unshift(x);result={ok:true,created:x}}
if(c.function.name==='update_task'&&task){Object.assign(task,Object.fromEntries(Object.entries(a).filter(([k])=>k!=='title')));result={ok:true,updated:task}}
if(c.function.name==='create_project'){let x={id:crypto.randomUUID(),name:a.name,category:a.category||'Other',progress:Math.min(100,Math.max(0,a.progress||0)),status:'Planning',nextStep:a.nextStep||'',updatedAt:now};d.projects.unshift(x);result={ok:true,created:x}}
if(c.function.name==='update_project'&&project){if(a.progress!==undefined)project.progress=Math.min(100,Math.max(0,a.progress));if(a.status)project.status=a.status;if(a.nextStep)project.nextStep=a.nextStep;result={ok:true,updated:project}}
if(c.function.name==='log_work'){let x={id:crypto.randomUUID(),...a,createdAt:now};d.workLogs.unshift(x);result={ok:true,saved:x}}
if(c.function.name==='save_note'){let x={id:crypto.randomUUID(),...a,createdAt:now};d.notes.unshift(x);result={ok:true,saved:x}}
messages.push({role:'tool',tool_call_id:c.id,content:JSON.stringify(result)})}
write(d)}
return {text:answer||'ดำเนินการแล้วครับ',data:read()}
});