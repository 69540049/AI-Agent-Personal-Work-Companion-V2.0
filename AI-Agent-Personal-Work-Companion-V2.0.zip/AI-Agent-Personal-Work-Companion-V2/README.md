# AI Agent — Personal Work Companion V2.0

A local-first macOS desktop starter built with Electron.

## Features
- Welcome Briefing with local task and project overview
- Real AI chat via an OpenAI-compatible Chat Completions API
- AI tool actions: create/update tasks and projects, log achievements, save knowledge notes
- Smart Task Manager, Project Intelligence, Work Memory
- AI-generated daily insight and planning on demand
- Performance summary and JSON export
- API key encrypted with Electron `safeStorage`
- Optional launch at macOS login

## Requirements
- macOS (recommended macOS 12+)
- Node.js 20+ and npm
- API key for a provider compatible with OpenAI Chat Completions and tool/function calling

## Run
1. Extract this ZIP.
2. Open Terminal and enter the project folder.
3. Run `npm install` then `npm start`.
4. Open **Settings & AI Connection** in the app.
5. Enter API Base URL, Model ID and API Key. Default Base URL: `https://api.openai.com/v1`.
6. Click **Test connection**, then **Save settings**.
7. Enable launch at login if desired.

## Build macOS installer
On a Mac, run `npm install` then `npm run dist:mac`. The `dist/` folder will contain DMG and ZIP packages. Code signing and Apple notarization are recommended before distributing the app to other Macs.

## Data and privacy
Tasks, projects, work logs, notes and preferences are stored in Electron's app user-data folder as `workspace.json`. API keys are encrypted with Electron `safeStorage` and stored separately. During AI requests, the user's message and current workspace context are sent to the configured AI provider. The app does not use a separate cloud database. Treat JSON exports as sensitive.

## Current scope / limitations
This ZIP is the editable source project, not a prebuilt or notarized `.dmg`. The AI needs a valid API key and a model that supports tool calling. Calendar sync, automatic file indexing, email integrations, push notifications, recurring scheduled briefings and background document ingestion are planned for subsequent releases. The Welcome Briefing currently summarizes local workspace data when the app opens; AI insight and planning are generated when requested.
